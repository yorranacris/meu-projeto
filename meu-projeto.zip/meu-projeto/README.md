# Entrega II — CSS3 Avançado

## 🎯 Objetivo
Aplicar CSS3 para transformar a estrutura da Entrega I em uma interface visual profissional, responsiva e acessível.

## 🧱 Estrutura
- HTML: index, sobre, projetos, contato
- CSS: base.css, layout.css, components.css, utilities.css
- Imagens em `/imagens`

## 🧩 Tecnologias
HTML5 + CSS3 (Grid, Flexbox, Variáveis CSS, Responsividade)

## 📐 Design System
- 8 cores (primárias, secundárias e neutras)
- Tipografia hierárquica (5 tamanhos)
- Espaçamento modular (8px, 16px, 24px, 32px, 48px, 64px)

## 🧰 Componentes
- Menu responsivo com dropdown e hambúrguer
- Grid 12 colunas
- Cards responsivos
- Botões com estados (hover, focus, active, disabled)
- Formulários com validação visual
- Alerts, Toasts e Modais
- Badges e Tags

## 🌍 Acesso
Este projeto é um modelo. Suba em um repositório público no GitHub e habilite GitHub Pages para visualização.
